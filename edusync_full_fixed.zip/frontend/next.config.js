module.exports = {
    reactStrictMode: true,
};