export const formatData = (data: string) => {
    return data.toUpperCase();
};